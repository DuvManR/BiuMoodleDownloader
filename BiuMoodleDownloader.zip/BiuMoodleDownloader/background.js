/**
 * Triggers when the extension icon is clicked in the toolbar.
 * Sends a command to toggle the floating GUI on the active page.
 */
chrome.action.onClicked.addListener((tab) => {
	chrome.tabs.sendMessage(tab.id, { action: "toggleGUI" }).catch(() => {
		console.log("The script is not yet loaded on this page.");
	});
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === "downloadFile") {
		chrome.downloads.download({
			url: request.url,
			filename: request.filename,
			conflictAction: "overwrite",
		});
	}
});
