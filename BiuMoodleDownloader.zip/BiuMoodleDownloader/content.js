let isAborted = false;
let isRunning = false;
let totalTasks = 0;
let completedTasks = 0;

/**
 * Listen for commands from the extension background/popup.
 * specifically to toggle the visibility of the floating window.
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === "toggleGUI") {
		createOrToggleGUI();
	}
});

/**
 * Creates or toggles the floating user interface (widget) injected directly into the page.
 */
function createOrToggleGUI() {
	let gui = document.getElementById("biu-downloader-widget");
	if (gui) {
		gui.style.display = gui.style.display === "none" ? "block" : "none";
		return;
	}

	gui = document.createElement("div");
	gui.id = "biu-downloader-widget";
	gui.dir = "ltr"; // Set to Left-To-Right for English layout

	// Styling the widget - rounded corners and modern shadow effects
	Object.assign(gui.style, {
		position: "fixed",
		bottom: "40px",
		left: "40px",
		width: "360px",
		backgroundColor: "#ffffff",
		borderRadius: "16px",
		boxShadow:
			"0 10px 30px rgba(27, 94, 32, 0.15), 0 1px 3px rgba(0,0,0,0.05)",
		zIndex: "999999",
		padding: "24px",
		fontFamily: '"Segoe UI", Tahoma, sans-serif',
		border: "1px solid #e8f5e9",
	});

	gui.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; border-bottom: 2px solid #e8f5e9; padding-bottom: 12px;">
            <h3 style="margin: 0; color: #1b5e20; font-size: 19px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
                <img src="${chrome.runtime.getURL(
					"icon.png"
				)}" alt="Logo" style="width: 32px; height: 32px; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
                BIU Moodle
            </h3>
            <button id="biu-close-btn" style="background: #f1f8e9; border: none; border-radius: 50%; width: 30px; height: 30px; font-size: 14px; cursor: pointer; color: #2e7d32; display: flex; align-items: center; justify-content: center; transition: background 0.2s;">✖</button>
        </div>
        <div style="display: flex; gap: 12px; margin-bottom: 20px;">
            <button id="biu-start-btn" style="flex: 2; background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 15px; box-shadow: 0 4px 10px rgba(46,125,50,0.3); transition: opacity 0.2s;">Start Scan</button>
            <button id="biu-stop-btn" disabled style="flex: 1; background: #ffebee; color: #d32f2f; border: 1px solid #ffcdd2; padding: 12px; border-radius: 8px; cursor: not-allowed; opacity: 0.5; font-weight: bold; font-size: 15px; transition: all 0.2s;">Stop</button>
        </div>
        <div style="background: #e8f5e9; border-radius: 8px; height: 14px; overflow: hidden; margin-bottom: 12px; border: 1px solid #c8e6c9;">
            <div id="biu-progress-fill" style="background: linear-gradient(90deg, #4caf50, #2e7d32); height: 100%; width: 0%; transition: width 0.4s ease-out; border-radius: 8px;"></div>
        </div>
        <div id="biu-status-text" style="font-size: 13px; color: #2e7d32; text-align: center; font-weight: 500;">Waiting to start...</div>
    `;

	document.body.appendChild(gui);

	// Hover effects for the close button to ensure responsive UI feel
	const closeBtn = document.getElementById("biu-close-btn");
	closeBtn.addEventListener(
		"mouseover",
		() => (closeBtn.style.background = "#dcedc8")
	);
	closeBtn.addEventListener(
		"mouseout",
		() => (closeBtn.style.background = "#f1f8e9")
	);
	closeBtn.addEventListener("click", () => {
		gui.style.display = "none";
	});

	document.getElementById("biu-start-btn").addEventListener("click", () => {
		if (isRunning) return;
		isAborted = false;
		isRunning = true;
		const startBtn = document.getElementById("biu-start-btn");
		startBtn.disabled = true;
		startBtn.style.opacity = "0.7";
		startBtn.style.cursor = "wait";

		const stopBtn = document.getElementById("biu-stop-btn");
		stopBtn.disabled = false;
		stopBtn.style.opacity = "1";
		stopBtn.style.cursor = "pointer";

		scrapeAndDownload();
	});

	document.getElementById("biu-stop-btn").addEventListener("click", () => {
		isAborted = true;
		document.getElementById("biu-status-text").innerText =
			"Stopping download...";
	});
}

/**
 * Updates the progress bar and status text within the widget.
 * @param {string} text - The current task description or file name.
 */
function updateProgress(text) {
	if (isAborted) return;
	completedTasks++;
	const percent =
		totalTasks === 0
			? 0
			: Math.min(Math.round((completedTasks / totalTasks) * 100), 100);
	document.getElementById("biu-progress-fill").style.width = percent + "%";
	document.getElementById(
		"biu-status-text"
	).innerText = `(${completedTasks}/${totalTasks}) ${text}`;
}

/**
 * Finalizes the process and resets the widget's UI state.
 * @param {string} msg - The final message to display.
 */
function finishProcess(msg) {
	isRunning = false;
	document.getElementById("biu-status-text").innerText = msg;

	document.getElementById("biu-start-btn").disabled = false;
	document.getElementById("biu-start-btn").style.opacity = "1";

	const stopBtn = document.getElementById("biu-stop-btn");
	stopBtn.disabled = true;
	stopBtn.style.opacity = "0.5";
	stopBtn.style.cursor = "not-allowed";
}

/**
 * Main function: Scans the Moodle page, extracts all relevant links,
 * resolves file extensions, and dispatches download requests.
 */
async function scrapeAndDownload() {
	let courseName = document.querySelector("h1")
		? document
				.querySelector("h1")
				.innerText.trim()
				.replace(/[\/\\?%*:|"<>]/g, "-")
				.replace(/\.+$/, "")
				.trim()
		: "General_Course";
	const courseFolderName = `Moodle_${courseName}_${Date.now()}`;

	const topBarVideos = document.querySelectorAll(
		"div.row[rowvid] .colsubject a"
	);
	const xpath = "//h3[contains(@class, 'sectionname')]//a";
	const sectionResult = document.evaluate(
		xpath,
		document,
		null,
		XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
		null
	);

	const sections = [];
	for (let i = 0; i < sectionResult.snapshotLength; i++) {
		sections.push({
			title: sectionResult.snapshotItem(i).innerText.trim(),
			url: sectionResult.snapshotItem(i).href,
		});
	}

	if (topBarVideos.length === 0 && sections.length === 0) {
		finishProcess("No files found for download on this page.");
		return;
	}

	totalTasks = topBarVideos.length + sections.length * 4;
	completedTasks = 0;
	updateProgress("Starting scan...");

	// 1. Process Top Bar Recordings
	if (topBarVideos.length > 0) {
		for (let i = 0; i < topBarVideos.length; i++) {
			if (isAborted) return finishProcess("Download stopped by user.");

			const a = topBarVideos[i];
			let cleanTitle = (a.getAttribute("title") || a.innerText)
				.trim()
				.replace(/[\/\\?%*:|"<>]/g, "-")
				.replace(/\.+$/, "")
				.trim();
			if (!cleanTitle) cleanTitle = `Video_${i + 1}`;

			const videoNumber = topBarVideos.length - i;
			const baseName = `(${videoNumber}) ${cleanTitle}`;

			try {
				const response = await fetch(a.href);
				const html = await response.text();
				const doc = new DOMParser().parseFromString(html, "text/html");

				let videoUrl = null;
				const videoNode = doc.querySelector("video source, video");
				if (videoNode) videoUrl = videoNode.src || videoNode.currentSrc;
				if (!videoUrl) {
					const mp4Match = html.match(/(https:\/\/[^\s"'<>]+\.mp4)/);
					if (mp4Match) videoUrl = mp4Match[1];
				}

				if (videoUrl) {
					const finalFilename = `${courseFolderName}/הקלטות מהסרגל/${baseName}.mp4`;
					chrome.runtime.sendMessage({
						action: "downloadFile",
						url: videoUrl,
						filename: finalFilename,
					});
					updateProgress(`Sent: ${baseName}`);
				}
			} catch (e) {
				console.error(`Error in top bar processing: ${baseName}`, e);
			}
			await new Promise((r) => setTimeout(r, 800));
		}
	}

	// 2. Process Course Sections
	for (let sIndex = 0; sIndex < sections.length; sIndex++) {
		if (isAborted) return finishProcess("Download stopped by user.");

		const section = sections[sIndex];
		// Fix preventing folder creation crash: removes trailing dots from the sanitized name
		const safeSectionTitle = section.title
			.replace(/[\/\\?%*:|"<>]/g, "-")
			.replace(/\.+$/, "")
			.trim();
		const sectionFolder = `(${sIndex + 1}) ${safeSectionTitle}`;

		try {
			const sectionResponse = await fetch(section.url);
			const sectionHtml = await sectionResponse.text();
			const doc = new DOMParser().parseFromString(
				sectionHtml,
				"text/html"
			);

			// --- Fix for Section 4 (A section that behaves like a folder) ---
			const directFolderFiles = doc.querySelectorAll(".fp-filename a");
			if (directFolderFiles.length > 0) {
				totalTasks += directFolderFiles.length;
				for (let i = 0; i < directFolderFiles.length; i++) {
					if (isAborted)
						return finishProcess("Download stopped by user.");
					const fileLink = directFolderFiles[i];
					const fileName = fileLink.innerText
						.trim()
						.replace(/[\/\\?%*:|"<>]/g, "-")
						.replace(/\.+$/, "")
						.trim();

					const finalFilename = `${courseFolderName}/${sectionFolder}/${fileName}`;
					chrome.runtime.sendMessage({
						action: "downloadFile",
						url: fileLink.href,
						filename: finalFilename,
					});

					updateProgress(fileName);
					await new Promise((r) => setTimeout(r, 600));
				}
			}
			// ----------------------------------------------------

			const linkElements = doc.querySelectorAll(
				".modtype_resource a, .modtype_url a, .modtype_videostream a, .modtype_folder a"
			);

			// --- Fix for videos containing the word 'Zoom' in their title ---
			// Only filter links that explicitly lead to the live Zoom module, allowing videos named "Zoom"
			const validLinks = Array.from(linkElements).filter(
				(a) =>
					!a.closest(".modtype_zoom") && !a.href.includes("mod/zoom/")
			);

			totalTasks += validLinks.length;

			for (let fIndex = 0; fIndex < validLinks.length; fIndex++) {
				if (isAborted)
					return finishProcess("Download stopped by user.");

				const a = validLinks[fIndex];
				let cloneA = a.cloneNode(true);
				cloneA
					.querySelectorAll(".accesshide")
					.forEach((node) => node.remove());

				let cleanTitle = (
					cloneA.getAttribute("title") || cloneA.innerText
				)
					.trim()
					.replace(/[\/\\?%*:|"<>]/g, "-")
					.replace(/\.+$/, "")
					.trim();
				if (!cleanTitle) cleanTitle = `File_${fIndex + 1}`;

				const baseName = `(${fIndex + 1}) ${cleanTitle}`;
				const isFolder = !!a.closest(".modtype_folder");

				if (isFolder) {
					try {
						const folderRes = await fetch(a.href);
						const folderHtml = await folderRes.text();
						const folderDoc = new DOMParser().parseFromString(
							folderHtml,
							"text/html"
						);

						const folderFiles =
							folderDoc.querySelectorAll(".fp-filename a");
						for (let i = 0; i < folderFiles.length; i++) {
							if (isAborted) break;
							const fileLink = folderFiles[i];
							const fileName = fileLink.innerText
								.trim()
								.replace(/[\/\\?%*:|"<>]/g, "-")
								.replace(/\.+$/, "")
								.trim();

							const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}/${fileName}`;
							chrome.runtime.sendMessage({
								action: "downloadFile",
								url: fileLink.href,
								filename: finalFilename,
							});
							await new Promise((r) => setTimeout(r, 600));
						}
					} catch (err) {}
				} else {
					let downloadUrl = a.href;
					let ext = "";
					let isExternalUrl = false;

					try {
						const headRes = await fetch(a.href);
						const contentType =
							headRes.headers.get("content-type") || "";

						if (contentType.includes("text/html")) {
							const html = await headRes.text();
							const innerDoc = new DOMParser().parseFromString(
								html,
								"text/html"
							);
							let fileUrl = null;
							let externalWorkaroundUrl = null;

							const videoNode = innerDoc.querySelector(
								"video source, video"
							);
							if (videoNode)
								fileUrl = videoNode.src || videoNode.currentSrc;
							if (!fileUrl) {
								const mp4Match = html.match(
									/(https:\/\/[^\s"'<>]+\.mp4)/
								);
								if (mp4Match) fileUrl = mp4Match[1];
							}
							if (!fileUrl) {
								const objectNode = innerDoc.querySelector(
									'object[type="application/pdf"]'
								);
								if (objectNode && objectNode.data)
									fileUrl = objectNode.data;
							}
							if (!fileUrl) {
								const directLink = innerDoc.querySelector(
									'.resourceworkaround a, a[href*="pluginfile.php"]'
								);
								if (directLink) fileUrl = directLink.href;
							}

							// Extract the actual link from the Bar-Ilan workaround page
							if (!fileUrl) {
								const urlWorkaround =
									innerDoc.querySelector(".urlworkaround a");
								if (urlWorkaround)
									externalWorkaroundUrl = urlWorkaround.href;
							}

							if (fileUrl) {
								// 1. File type check remains via fetch (server correctly returns the extension here)
								const controller = new AbortController();
								try {
									const innerRes = await fetch(fileUrl, {
										signal: controller.signal,
									});
									ext = getExtension(
										innerRes.url,
										innerRes.headers.get("content-type") ||
											""
									);
									controller.abort();
								} catch (e) {
									if (fileUrl.includes(".mp4")) ext = ".mp4";
									else if (fileUrl.includes(".pdf"))
										ext = ".pdf";
								}

								// 2. The proper solution against Moodle's security blocks!
								// Uses Moodle's official direct download link parameter instead of the internal blocked link
								if (a.href.includes("mod/resource/view.php")) {
									downloadUrl = a.href.includes("?")
										? a.href + "&redirect=1"
										: a.href + "?redirect=1";
								} else {
									downloadUrl = fileUrl.includes("?")
										? fileUrl + "&forcedownload=1"
										: fileUrl + "?forcedownload=1";
								}
							} else if (externalWorkaroundUrl) {
								// Found a real external URL!
								downloadUrl = externalWorkaroundUrl;
								isExternalUrl = true;
							} else {
								continue;
							}
						} else {
							ext = getExtension(headRes.url, contentType);
						}

						// Save external links as TXT files
						if (
							isExternalUrl ||
							(!ext &&
								!a.closest(".modtype_videostream") &&
								!downloadUrl.includes(".mp4"))
						) {
							ext = ".txt";
							const txtContent = `Moodle Link Name: ${cleanTitle}\n\nSource Link (Extracted from Workaround):\n${downloadUrl}`;
							downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
								txtContent
							)}`;
						} else if (!ext && a.closest(".modtype_videostream")) {
							ext = ".mp4";
						}

						const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}${ext}`;
						chrome.runtime.sendMessage({
							action: "downloadFile",
							url: downloadUrl,
							filename: finalFilename,
						});
					} catch (err) {}
				}
				updateProgress(baseName);
				await new Promise((r) => setTimeout(r, 800));
			}
		} catch (error) {}
	}

	if (!isAborted) {
		completedTasks = totalTasks;
		document.getElementById("biu-progress-fill").style.width = "100%";
		finishProcess("All files sent for download!");
	}
}

/**
 * Utility function to determine the file extension based on the URL and Content-Type header.
 * @param {string} url - The URL being fetched.
 * @param {string} contentType - The Content-Type header from the response.
 * @returns {string} - The file extension (e.g., '.pdf').
 */
function getExtension(url, contentType) {
	url = (url || "").toLowerCase();
	contentType = (contentType || "").toLowerCase();
	if (contentType.includes("pdf")) return ".pdf";
	if (contentType.includes("mp4") || contentType.includes("video"))
		return ".mp4";
	if (contentType.includes("word") || contentType.includes("document"))
		return ".docx";
	if (
		contentType.includes("powerpoint") ||
		contentType.includes("presentation")
	)
		return ".pptx";
	if (contentType.includes("excel") || contentType.includes("sheet"))
		return ".xlsx";
	if (contentType.includes("zip")) return ".zip";
	const match = url.match(/\.([a-z0-9]+)(?:\?|#|$)/i);
	if (match && match[1] !== "php") return `.${match[1]}`;
	return "";
}
