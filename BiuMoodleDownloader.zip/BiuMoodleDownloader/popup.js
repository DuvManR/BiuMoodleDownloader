document.getElementById("startBtn").addEventListener("click", () => {
	const startBtn = document.getElementById("startBtn");
	const progressContainer = document.getElementById("progressContainer");
	const statusText = document.getElementById("statusText");

	startBtn.disabled = true;
	startBtn.innerText = "Process is running...";
	progressContainer.style.display = "block";
	statusText.innerText = "Starting course scan...";

	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		chrome.tabs.sendMessage(tabs[0].id, { action: "startDownload" });
	});
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === "updateProgress") {
		const fill = document.getElementById("progressFill");
		const statusText = document.getElementById("statusText");

		const percent =
			Math.round((request.current / request.total) * 100) || 0;
		fill.style.width = percent + "%";
		statusText.innerText = `Processing: ${request.current}/${request.total} - ${request.text}`;

		if (request.current >= request.total) {
			document.getElementById("startBtn").innerText =
				"Finished Successfully!";
			statusText.innerText = "All files have been queued for download!";
		}
	}
});
